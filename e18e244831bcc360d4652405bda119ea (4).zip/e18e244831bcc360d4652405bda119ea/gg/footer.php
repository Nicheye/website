<footer class = "footer center">
      <div class = "contacts">
       
        <p class = "text">Copyright &copy; UNIVERO LEVERAGE | All Rights Reserved</p>
        
          
        </div>
      </div>
    </footer>
    <!-- end of footer -->





<?php wp_footer(); ?>
   
    
  </body>
</html>